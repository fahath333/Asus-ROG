import 'bootstrap/dist/css/bootstrap.min.css';
//import lg from './logo.png';
import im2 from './img2.png';
import im3 from './img3.png';
import im4 from './img4.png';
import im5 from './img5.png';
import im6 from './img6.png';
import im7 from './img7.png';
import im8 from './im8.gif';
import img9 from "./img9.gif";
import img10 from './img10.jpg';
import bg1 from './bg1.jpg';
import { Container,Row,Col } from 'react-bootstrap';
import {} from 'react-bootstrap'
import React from 'react' 
import {  } from "./boot.css";
export default function App() {
  return (
    
    
    <div className='color'>
      <img className='bg1' src="bg1"srcset={bg1} />
       
        <table className='nav'>
             <Row>
             <Col lg={{span:4,offset:0}}md={{span:6,offset:3}}sm={{span:12,offset:6}}>
            <tr >
            <td> <img className='im8' src={im8}/></td>
            <td> <img className='im9'  src={img9}/></td>
            <td> <img className='img10'src={img10}/></td> 
                 </tr>
            </Col>

             </Row>
               </table>
       <table className='mg'>
        <Container>
            <Row>
    
          <Col lg={{span:4,offset:0}}md={{span:6,offset:3}}sm={{span:12,offset:6}}>
            <tr>
                 <td><img className='si' src={im2} />
                 <h4>ROG Flow X13 (2022)
GV301RA-LI030WS</h4>
                <ul>
                  <li>Windows 11 Home</li>
                  <li>AMD Ryzen™ 7 6800HS</li>
                  <li>34.03cm(13.4"), UHD+ 16:10 (3840 x 2400, WQUXGA),</li>
                  <li>1TB PCIe® 4.0 NVMe™ M.2 SSD (2230)</li>
                </ul>
                <h2>₹ 2,47,990.00</h2>
                <input className='rd' type={"button"} value={"BUY NOW"}/>
                 </td>
                 </tr>
                 </Col>
                 <Col lg={{span:4,offset:0}}md={{span:6,offset:3}}sm={{span:12,offset:6}}>
              <tr>
            <td><img className='siz'  src={im3} />
                 <h4>ROG Flow X16 (2022)
GV601RW-M5045WS</h4>
                <ul>
                  <li>Windows 11 Home</li>
                  <li>AMD Ryzen™ 9 6900HS,</li>
                  <li>ROG Nebula HDR Display</li>
                  <li>40.64cm(16"), QHD+ 16:10 (2560 x 1600, WQXGA), Refresh Rate:165Hz</li>
                  <li>1TB M.2 NVMe™ PCIe® 4.0 SSD Supports slots up to max of: 4TB M.2 NVMe™ PCIe® 4.0 SSD</li>
                </ul>
                <h2>₹2,71,980.00</h2>
                <input className='rd' type={"button"} value={"BUY NOW"}/>
                 </td>
                 </tr>
                 </Col>
                 <Col lg={{span:4,offset:0}}md={{span:6,offset:3}}sm={{span:12,offset:6}}>
                 <tr>
                 <td><img className='size' src={im4}/>
                 <h4>ROG Flow Z13 (2022)
GZ301ZE-LC193WS</h4>
               <ul>
                  <li>GeForce RTX™ 3050 Ti Laptop GPU</li>
                  <li>Windows 11 Home</li>
                  <li>12th Gen Intel® Core™ i9-12900H</li>
                  <li>34.03cm(13.4"), UHD+ 16:10 (3840 x 2400, WQUXGA),</li>
                  <li>1TB PCIe® 4.0 NVMe™ M.2 SSD (2230)</li>
                </ul>
                <h2>₹ 1,81,990.00</h2>
                <input className='rd' type={"button"} value={"BUY NOW"}/>
                 </td>
                 </tr>
            </Col>
            <Col lg={{span:4,offset:0}}md={{span:6,offset:3}}sm={{span:12,offset:6}}>
                 <tr>
                 <td><img className='size' src={im5}/>
                 <h4>2021 ROG Strix G15
G513IC-HN023WS</h4>
               <ul>
                  <li>GeForce RTX™ 3050 Ti Laptop GPU</li>
                  <li>Windows 11 Home</li>
                  <li>AMD Ryzen™ 7 4800H</li>
                  <li>39.62cm(15.6"), FHD (1920 x 1080) 16:9, Refresh Rate:144Hz</li>
                  <li>512GB M.2 NVMe™ PCIe® 3.0 SSD Supports slots up to max of: 1TB PCIe NVMe SSD M.2 2280 slot</li>
                </ul>
                <h2>₹ 93,990.00</h2>
                <input className='rd' type={"button"} value={"BUY NOW"}/>
                 </td>
                 </tr>
            </Col>
            <Col lg={{span:4,offset:0}}md={{span:6,offset:3}}sm={{span:12,offset:6}}>
                 <tr>
                 <td><img className='size' src={im6}/>
                 <h4>ROG Strix Scar 17 SE (2022)
G733CX-LL012WS</h4>
               <ul>
                  <li>NVIDIA® GeForce RTX™ 3080 Ti Laptop GPU</li>
                  <li>Windows 11 Home</li>
                  <li>12th Gen Intel® Core™ i9-12950HX</li>
                  <li>43.94cm(17.3"), WQHD (2560 x 1440) 16:9, Refresh Rate:240Hz</li>
                  <li>2TB + 2TB PCIe® 4.0 NVMe™ M.2 Performance SSD (RAID 0)</li>
                </ul>
                <h2>₹4,20,990</h2>
                <input className='rd' type={"button"} value={"BUY NOW"}/>
                 </td>
                 </tr>
            </Col>

            <Col lg={{span:4,offset:0}}md={{span:6,offset:3}}sm={{span:12,offset:6}}>
                 <tr>
                 <td><img className='size' src={im7}/>
                 <h4>ROG Strix G15 Advantage Edition
G513QY-HQ032WS</h4>
               <ul>
                  <li>AMD Radeon™ RX 6800M</li>
                  <li>Windows 11 Home</li>
                  <li>AMD Ryzen™ 9 5980HX</li>
                  <li>39.62cm(15.6"), WQHD (2560 x 1440) 16:9, Refresh Rate:165Hz</li>
                  <li>1TB M.2 NVMe™ PCIe® 3.0 SSD</li>
                </ul>
                <h2>₹1,45,990</h2>
                <input className='rd' type={"button"} value={"BUY NOW"}/><br/><br/>
                
                
                 </td>
                 </tr>
            </Col>
            </Row>
        </Container>
        </table>
        
    </div>
    
  )
}
